﻿using System;

namespace CM5
{
    class Program
    {
        static void Main(string[] args)
        {
            Arme     epée     = new Arme(50);
            Bouclier bouclier = new Bouclier(30);

            Troll t1 = new Troll("a", 100);
            t1.Arme     = epée;
            t1.Bouclier = bouclier;

            Troll t2 = new Troll("b", 100);
            t2.Arme     = epée;
            t2.Bouclier = bouclier;

            t1.Attaque(t2);
            Console.WriteLine(t2.Vie);

            Personnage gus = new Personnage("c", 100);
            t1.Attaque(gus);
            Console.WriteLine(gus.Vie);
        }
    }

    abstract class Destructible
    {
        private readonly string _nom;

        public Destructible(string nom)
        {
            _nom = nom;
        }

        public string Nom
        {
            get { return _nom; }
        }

        // [Java] @Abstract
        public abstract void Blesse(int attaque);
    }

    class Personnage : Destructible
    {
        private int _vie;

        public Personnage(string nom, int vie) : base(nom)
        {
            _vie = vie;
        }

        public int Vie
        {
            get { return _vie; }
        }

        // [Java] @Override
        public override void Blesse(int attaque)
        {
            _vie = Math.Max(0, _vie - Défend(attaque));
        }

        // Un personnage lambda ne se défend pas
        protected virtual int Défend(int attaque)
        {
            return attaque;
        }
    }

    class Troll : Personnage
    {
        private     Arme _arme;
        private Bouclier _bouclier;

        public Troll(string nom, int vie) : base(nom, vie)
        {
            // [Java] super(vie);
        }

        public void Attaque(Destructible cible)
        {
            cible.Blesse(_arme.Puissance);
        }

        public Arme Arme
        {
            get { return _arme; }
            set { _arme = value; }
        }

        // public Arme Arme { get; set; }

        protected override int Défend(int attaque)
        {
            return Math.Max(0, attaque - _bouclier.Resistance);
        }

        public Bouclier Bouclier
        {
            get { return _bouclier; }
            set { _bouclier = value; }
        }

        // public Bouclier Bouclier { get; set; }
    }

    class Arme
    {
        private readonly int _puissance;

        public Arme(int puissance)
        {
            _puissance = puissance;
        }

        public int Puissance
        {
            get { return _puissance; }
        }
    }

    class Bouclier
    {
        private readonly int _resistance;

        public Bouclier(int resistance)
        {
            _resistance = resistance;
        }

        public int Resistance
        {
            get { return _resistance; }
        }
    }
}
