﻿using System;

namespace CM5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine(Puissance2_Recursive(10));

            Console.WriteLine(Puissance2_Imperative(10));

            Func<int> p = Puissances2();
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            */

            Func<int> c = Compteur();
            //Func<int> p = Pair(c);
            Func<int> p = Filtre(c, i => i % 2 == 0);

            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
            Console.WriteLine(p());
        }

        static int Puissance2_Recursive(int n)
        {
            if (n == 0)
                return 1;
            else 
                return 2 * Puissance2_Recursive(n - 1);
        }

        static int Puissance2_Imperative(int n)
        {
            int res = 1;
            while (n > 0)
            {
                res = 2 * res;
                n--;
            }

            return res;
        }

        // Puissances2 produit une fonction, qui produit un entier
        static Func<int> Puissances2()
        {
            int res = 1;

            return () =>
            {
                int r = res;
                res = 2 * res;
                return r;
            };
        }

        // En C# :
        //
        // Func<T>       : fonction produisant T
        // Func<A, T>    : fonction produisant T à partir de A
        // Func<A, B, T> : fonction produisant T à partir de A et de B
        //
        // Action        : fonction sans valeur de retour
        // Action<A>     : fonction sans valeur de retour à partir de A
        // Action<A, B>  : fonction sans valeur de retour à partir de A et de B

        static Func<int> Compteur()
        {
            int res = 1;

            return () =>
            {
                int r = res;
                res = res + 1;
                return r;
            };
        }

        static Func<int> Pair(Func<int> pioche)
        {
            return () =>
            {
                int res = pioche();
                while (res % 2 != 0)
                {
                    res = pioche();
                }
                
                return res;
            };
        }

        //static Func<int> Filtre(Func<int> pioche, Func<int, bool> condition)
        //{
        //    return () =>
        //    {
        //        int res = pioche();
        //        while (!condition(res))
        //        {
        //            res = pioche();
        //        }
        //
        //        return res;
        //    };
        //}

        static Func<T> Filtre<T>(Func<T> pioche, Func<T, bool> condition)
        {
            return () =>
            {
                T res = pioche();
                while (!condition(res))
                {
                    res = pioche();
                }

                return res;
            };
        }
    }
}
