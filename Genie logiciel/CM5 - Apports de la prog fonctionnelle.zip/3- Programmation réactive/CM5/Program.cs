﻿using System;
using System.Collections.Generic;

namespace CM5
{
    class Program
    {
        static void Main(string[] args)
        {
            CompteurObservable c = new CompteurObservable();

            IObservable<int> p = new Pair(c);

            WriteLine<int> o = new WriteLine<int>();
            c.Abonne(o);

            p.Abonne(new WriteLineVoici<int>());

            for (;;)
            {
                c.Declenche();
                Console.ReadKey();
            }
        }
    }

    interface IObservateur<T>
    {
        void Recoit(T valeur);
    }

    interface IObservable<T>
    {
        void Abonne(IObservateur<T> o);

        void Desabonne(IObservateur<T> o);
    }

    class CompteurObservable : IObservable<int>
    {
        private readonly List<IObservateur<int>> _abonnes = new List<IObservateur<int>>();

        private int _courant;

        public void Abonne(IObservateur<int> o)
        {
            _abonnes.Add(o);
        }

        public void Desabonne(IObservateur<int> o)
        {
            _abonnes.Remove(o);
        }

        public void Declenche()
        {
            foreach (IObservateur<int> o in _abonnes)
            {
                o.Recoit(_courant);
            }

            _courant++;
        }
    }

    class WriteLine<T> : IObservateur<T>
    {
        public void Recoit(T valeur)
        {
            Console.WriteLine(valeur);
        }
    }


    class WriteLineVoici<T> : IObservateur<T>
    {
        public void Recoit(T valeur)
        {
            Console.WriteLine($"Voici {valeur}");
        }
    }

    class Pair : IObservable<int>, IObservateur<int>
    {
        private readonly IObservable<int> _source;
        private readonly List<IObservateur<int>> _abonnes = new List<IObservateur<int>>();

        public Pair(IObservable<int> source)
        {
            _source = source;
            _source.Abonne(this);
        }

        public void Abonne(IObservateur<int> o)
        {
            _abonnes.Add(o);
        }

        public void Desabonne(IObservateur<int> o)
        {
            _abonnes.Remove(o);
        }

        public void Recoit(int valeur)
        {
            if (valeur % 2 == 0)
            {
                foreach (IObservateur<int> o in _abonnes)
                {
                    o.Recoit(valeur);
                }
            }
        }
    }
}
