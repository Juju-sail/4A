﻿using System;
using System.Collections.Generic;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            ITribu<int> I = new Intervalle(10, 20);

            for (ICompteur<int> c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            /*
            //ITribu<int> T = new Tableau(new []{ 16, 45, 62 });
            ITribu<int> T = new Tableau<int>(new[] { 16, 45, 62 });
            for (ICompteur<int> c = T.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
            */
                        
            ITribu<string> T = new Tableau<string>(new[] { "abc", "def", "ghi" });

            for (ICompteur<string> c = T.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
        }
    }

    interface ITribu<T>
    {
        ICompteur<T> Demarre();
    }

    interface ICompteur<T>
    {
        bool Avance();

        T Courant { get; }
    }

    class Intervalle : ITribu<int>
    {
        private readonly int _depart;
        private readonly int _arrivee;

        public Intervalle(int depart, int arrivee)
        {
            _depart  = depart;
            _arrivee = arrivee;
        }

        public ICompteur<int> Demarre()
        {
            return new CompteurIntervalle(_depart, _arrivee);
        }
    }

    class CompteurIntervalle : ICompteur<int>
    {
        private int _courant;
        private int _arrivee;

        public CompteurIntervalle(int depart, int arrivee)
        {
            _courant = depart - 1;
            _arrivee = arrivee;
        }

        public bool Avance()
        {
            _courant++;
            return _courant <= _arrivee;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }

    class Tableau : ITribu<int>
    {
        private readonly int[] _tableau;

        public Tableau(int[] tableau)
        {
            _tableau = tableau;
        }

        public ICompteur<int> Demarre()
        {
            return new CompteurTableau(_tableau);
        }
    }

    class CompteurTableau : ICompteur<int>
    {
        private readonly int[] _tableau;
        private            int _courant;

        public CompteurTableau(int[] tableau)
        {
            _tableau = tableau;
            _courant = -1;
        }

        public bool Avance()
        {
            _courant++;
            return _courant < _tableau.Length;
        }

        public int Courant
        {
            get { return _tableau[_courant]; }
        }
    }

    class Tableau<T> : ITribu<T>
    {
        private readonly T[] _tableau;

        public Tableau(T[] tableau)
        {
            _tableau = tableau;
        }

        public ICompteur<T> Demarre()
        {
            return new CompteurTableau<T>(_tableau);
        }
    }

    class CompteurTableau<T> : ICompteur<T>
    {
        private readonly T[] _tableau;
        private          int _courant;

        public CompteurTableau(T[] tableau)
        {
            _tableau = tableau;
            _courant = -1;
        }

        public bool Avance()
        {
            _courant++;
            return _courant < _tableau.Length;
        }

        public T Courant
        {
            get { return _tableau[_courant]; }
        }
    }
}
