﻿using System;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            /*
            // for ( démarrage; condition; action; )
            for (Compteur c = new Compteur(); c.Avance(); )
            {
                Console.WriteLine(c.Courant);
                Console.ReadKey();
            }
            */

            /*
            for (CompteurIntervalle c = new CompteurIntervalle(10, 20); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            // Equivalent à :
            // for (int i = 10; i <= 20; i++)
            // {
            //     Console.WriteLine(i);
            // }
            */

            Intervalle I = new Intervalle(10, 20);

            for (CompteurIntervalle c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            for (CompteurIntervalle c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
        }
    }

    class Compteur
    {
        private int _courant = -1;

        public bool Avance()
        {
            _courant++;
            return true;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }

    class Intervalle
    {
        private readonly int _depart;
        private readonly int _arrivee;

        public Intervalle(int depart, int arrivee)
        {
            _depart  = depart;
            _arrivee = arrivee;
        }

        public CompteurIntervalle Demarre()
        {
            return new CompteurIntervalle(_depart, _arrivee);
        }
    }

    class CompteurIntervalle
    {
        private int _courant;
        private int _arrivee;

        public CompteurIntervalle(int depart, int arrivee)
        {
            _courant = depart - 1;
            _arrivee = arrivee;
        }

        public bool Avance()
        {
            _courant++;
            return _courant <= _arrivee;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }
}
