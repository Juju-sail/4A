﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // Collection construite depuis un tableau de string :

            // [Java] Iterable<string>
            IEnumerable<string> T = new[] { "abc", "def", "ghi" };

            // [Java] Iterator<string>
            //for (IEnumerator<string> e = T.GetEnumerator(); e.MoveNext();)
            //{
            //    Console.WriteLine(e.Current);
            //}

            // [Java] for (string s : T)
            foreach (string s in T)
            {
                Console.WriteLine(s);
            }

            // Collection construite depuis un intervalle :

            IEnumerable<int> I = Enumerable.Range(10, 11);

            foreach (int i in I)
            {
                Console.WriteLine(i);
            }
        }
    }
}
