﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            IEnumerable<int> E = Enumerable.Range(0, 100);

            // LINQ : Language INtegrated Query
            // Opérateurs Select et Where

            IEnumerable<int> Ex2 = E.Select(x => 2 * x); // Projete pour chaque élément son double

            foreach (int e in Ex2)
            {
                Console.WriteLine(e);
            }

            IEnumerable<string> Estring = E.Select(x => $"Voici {x}"); // Projete pour chaque élément une représentation en string

            foreach (string e in Estring)
            {
                Console.WriteLine(e);
            }

            IEnumerable<int> Eimpair = E.Where(x => x % 2 == 1); // Filtre chaque élément impair

            foreach (int e in Eimpair)
            {
                Console.WriteLine(e);
            }

            IEnumerable<string> Eimpairstring = E
                .Where(x => x % 2 == 1) // Filtre chaque élément impair
                .Select(x => $"Voici {x}");  // Projete pour chaque élément une représentation en string

            foreach (string e in Eimpairstring)
            {
                Console.WriteLine(e);
            }

            // LINQ syntaxe requête
            IEnumerable<string> Eimpairstring_bis = from e in E
                                                    where e % 2 == 1
                                                    select $"Voici {e}";
        }
    }
}
