﻿using System;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            /*
            Intervalle I = new Intervalle(10, 20);

            for (CompteurIntervalle c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            for (CompteurIntervalle c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
            */

            /*
            //int[] T = new int[3];
            //T[0] = 16;
            //T[1] = 45;
            //T[2] = 62;

            int[] T = { 16, 45, 62 };

            for (CompteurTableau c = new CompteurTableau(T); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
            */

            Tableau T = new Tableau(new []{ 16, 45, 62 });

            for (CompteurTableau c = T.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
        }
    }

    class Intervalle
    {
        private readonly int _depart;
        private readonly int _arrivee;

        public Intervalle(int depart, int arrivee)
        {
            _depart  = depart;
            _arrivee = arrivee;
        }

        public CompteurIntervalle Demarre()
        {
            return new CompteurIntervalle(_depart, _arrivee);
        }
    }

    class CompteurIntervalle
    {
        private int _courant;
        private int _arrivee;

        public CompteurIntervalle(int depart, int arrivee)
        {
            _courant = depart - 1;
            _arrivee = arrivee;
        }

        public bool Avance()
        {
            _courant++;
            return _courant <= _arrivee;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }

    class Tableau
    {
        private readonly int[] _tableau;

        public Tableau(int[] tableau)
        {
            _tableau = tableau;
        }

        public CompteurTableau Demarre()
        {
            return new CompteurTableau(_tableau);
        }
    }

    class CompteurTableau
    {
        private readonly int[] _tableau;
        private            int _courant;

        public CompteurTableau(int[] tableau)
        {
            _tableau = tableau;
            _courant = -1;
        }

        public bool Avance()
        {
            _courant++;
            return _courant < _tableau.Length;
        }

        public int Courant
        {
            get { return _tableau[_courant]; }
        }
    }
}
