﻿using System;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            ITribu I = new Intervalle(10, 20);

            for (ICompteur c = I.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            ITribu T = new Tableau(new []{ 16, 45, 62 });

            for (ICompteur c = T.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
        }
    }

    interface ITribu
    {
        ICompteur Demarre();
    }

    interface ICompteur
    {
        bool Avance();

        int Courant { get; }
    }

    class Intervalle : ITribu
    {
        private readonly int _depart;
        private readonly int _arrivee;

        public Intervalle(int depart, int arrivee)
        {
            _depart  = depart;
            _arrivee = arrivee;
        }

        public ICompteur Demarre()
        {
            return new CompteurIntervalle(_depart, _arrivee);
        }
    }

    class CompteurIntervalle : ICompteur
    {
        private int _courant;
        private int _arrivee;

        public CompteurIntervalle(int depart, int arrivee)
        {
            _courant = depart - 1;
            _arrivee = arrivee;
        }

        public bool Avance()
        {
            _courant++;
            return _courant <= _arrivee;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }

    class Tableau : ITribu
    {
        private readonly int[] _tableau;

        public Tableau(int[] tableau)
        {
            _tableau = tableau;
        }

        public ICompteur Demarre()
        {
            return new CompteurTableau(_tableau);
        }
    }

    class CompteurTableau : ICompteur
    {
        private readonly int[] _tableau;
        private            int _courant;

        public CompteurTableau(int[] tableau)
        {
            _tableau = tableau;
            _courant = -1;
        }

        public bool Avance()
        {
            _courant++;
            return _courant < _tableau.Length;
        }

        public int Courant
        {
            get { return _tableau[_courant]; }
        }
    }
}
