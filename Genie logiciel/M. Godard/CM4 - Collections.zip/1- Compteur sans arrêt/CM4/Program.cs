﻿using System;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            /*
            Compteur c = new Compteur();

            // while (true)
            for (;;)
            {
                Console.WriteLine(c.Courant);
                Console.ReadKey();
                c.Avance();
            }
            */

            // for ( démarrage; condition; action; )
            for (Compteur c = new Compteur(); ; c.Avance())
            {
                Console.WriteLine(c.Courant);
                Console.ReadKey();
            }
        }
    }

    class Compteur
    {
        private int _courant = 0;

        public void Avance()
        {
            _courant++;
        }

        public int Courant
        {
            get { return _courant; }
        }
    }
}
