﻿using System;
using System.Collections.Generic;

namespace CM4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            ITribu<int> I = new Intervalle(10, 20);

            // =============== PROJECTION ===============

            for (ICompteur<int> c = I.Demarre(); c.Avance();)
            {
                int n = c.Courant % 7; // Projection
                Console.WriteLine(n);
            }

            ITribu<int> Imod7 = new Modulo7(I); // Projection, déclaré hors de la boucle

            for (ICompteur<int> c = Imod7.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            //ITribu<int> Imod5 = new Projection<int, int>(I, Modulo5);
            ITribu<int> Imod5 = new Projection<int, int>(I, i => i % 5); // [JS] function(i) { return i % 5; } 

            for (ICompteur<int> c = Imod5.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }

            // =============== FILTRAGE ===============

            for (ICompteur<int> c = I.Demarre(); c.Avance();)
            {
                if (c.Courant % 4 == 0) // Filtrage
                {
                    Console.WriteLine(c.Courant);
                }
            }

            ITribu<int> Ifiltre = new Filtrage<int>(I, i => i % 4 == 0); // Filtrage, déclaré hors de la boucle

            for (ICompteur<int> c = Ifiltre.Demarre(); c.Avance();)
            {
                Console.WriteLine(c.Courant);
            }
        }

        static int Modulo5(int i)
        {
            return i % 5;
        }
    }
}
