﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CM4
{
    class Modulo7 : ITribu<int>
    {
        private readonly ITribu<int> _source;

        public Modulo7(ITribu<int> source)
        {
            _source = source;
        }

        public ICompteur<int> Demarre()
        {
            return new CompteurModulo7(_source.Demarre());
        }
    }

    class CompteurModulo7 : ICompteur<int>
    {
        private readonly ICompteur<int> _source;

        public CompteurModulo7(ICompteur<int> source)
        {
            _source = source;
        }

        public bool Avance()
        {
            return _source.Avance();
        }

        public int Courant
        {
            get { return _source.Courant % 7; }
        }
    }

    // S : type des éléments sources
    // T : type des éléments cibles
    class Projection<S, T> : ITribu<T>
    {
        private readonly  ITribu<S> _source;
        private readonly Func<S, T> _projection;

        public Projection(ITribu<S> source, Func<S, T> projection)
        {
            _source     = source;
            _projection = projection;
        }

        public ICompteur<T> Demarre()
        {
            return new CompteurProjection<S, T>(_source.Demarre(), _projection);
        }
    }

    class CompteurProjection<S, T> : ICompteur<T>
    {
        private readonly ICompteur<S> _source;
        private readonly   Func<S, T> _projection;

        public CompteurProjection(ICompteur<S> source, Func<S, T> projection)
        {
            _source     = source;
            _projection = projection;
        }

        public bool Avance()
        {
            return _source.Avance();
        }

        public T Courant
        {
            get { return _projection(_source.Courant); }
        }
    }

    class Filtrage<T> : ITribu<T>
    {
        private readonly     ITribu<T> _source;
        private readonly Func<T, bool> _filtre;

        public Filtrage(ITribu<T> source, Func<T, bool> filtre)
        {
            _source = source;
            _filtre = filtre;
        }

        public ICompteur<T> Demarre()
        {
            return new CompteurFiltrage<T>(_source.Demarre(), _filtre);
        }
    }

    class CompteurFiltrage<T> : ICompteur<T>
    {
        private readonly  ICompteur<T> _source;
        private readonly Func<T, bool> _filtre;

        public CompteurFiltrage(ICompteur<T> source, Func<T, bool> filtre)
        {
            _source = source;
            _filtre = filtre;
        }

        public bool Avance()
        {
            while (_source.Avance())
            {
                if (_filtre(_source.Courant)) return true;
            }

            return false;
        }

        public T Courant
        {
            get { return _source.Courant; }
        }
    }
}
